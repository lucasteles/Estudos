const fetch = require('node-fetch');

const token = "d13c0e0a5f85af966f8d3b792ece89d3"
const number = "11960623526"
const route = path => `https://api.totalvoice.com.br${path}`

const call = (from, to, token) => {

    let data = JSON.stringify(  
        { 
            numero_destino: to,
            url_audio: 'http://www.minidisc.org/charman/1sec.mp3',
            resposta_usuario : true,
            bina: from
        })

    return fetch(route('/audio'), { 
        method: 'POST',
        body: data,
        headers: { 'Access-Token': token, 'Accept': 'application/json' },
  })}

const getNumber = () => Math.floor(100000000 + Math.random() * 900000000)
const sleep = (ms) => new Promise(resolve=>setTimeout(resolve,ms))

;(async function () {
 
        while (true)
        {
            let time = (Math.random()*10)*1000*60
            let from = getNumber()    
            
            let x = await call(number,number,token)

            await sleep(time)
        }
   
})()

