﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityTeste.Models;

namespace EntityTeste
{
    class Program
    {
        static void Main(string[] args)
        {

            using (var repo = new Repository<Cliente>())
            {
                var all = repo.dbQuery.ToList();

                foreach (var item in all)
                {
                    Console.Write(item.Name+"\n");
                }

            }

            Console.ReadKey();

        }
    }
}
