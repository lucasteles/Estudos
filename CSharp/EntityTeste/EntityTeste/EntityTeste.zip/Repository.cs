﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using System.Configuration;

namespace EntityTeste
{
    public class Repository<T> : DbContext where T : class, new()
    {
        /// <summary>
        /// Objeto de DbSet para acessar as funções de model do Entity Framework
        /// </summary>
        public DbSet<T> DbObject { get; set; }
        private string nameOrConnectionString = string.Empty;


        public IQueryable<T> dbQuery;

       
        public Repository()
            : base( ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString )
        {
            System.Data.Entity.Database.SetInitializer<Repository<T>>(null);
            this.dbQuery = this.DbObject;
            this.Configuration.LazyLoadingEnabled = false;
            this.Configuration.ProxyCreationEnabled = false;
            this.Configuration.AutoDetectChangesEnabled = false;
            this.Database.CommandTimeout = 99999;         

        }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
                       
            base.OnModelCreating(modelBuilder);
            
        }



    }
}
